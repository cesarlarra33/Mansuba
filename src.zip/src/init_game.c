#include <stdio.h>
#include <stdlib.h>

#include "init_game.h"


void print_type_vict(unsigned int type_victoire)
{
    switch (type_victoire)
    {
        case 1:
            printf("type de victoire : victoire complexe\n");
            break;
        case 0:
            printf("type de victoire : victoire simple\n");
            break;
    }
}


void print_type_game_board(unsigned int seed)
{
    switch (seed)
    {
    case 0:
        printf("seed = %u -> plateau rectangulaire avec relations dans toutes les directions.\n", seed);
        break;
    case 2:
        printf("seed = %u -> plateau triangulaire (bord étoilé).\n", seed);
        break;
    case 1:
        printf("seed = %u -> plateau triangulaire avec relations N, NW, W,  E, SE.\n", seed);
        break;
    default:
        break;
    }
}


/** fonction qui place les pièces dans la configuration de départ choisie (0 pour l'instant) dans le monde en fonction de la forme du monde */
void init_set_p0(unsigned int choix_pos_depart, struct set *s) // test ok pour choix_pos_depart=0
{
    unsigned int taille = tailles();
    unsigned int h = haut(taille);
    unsigned int ligne = 0;
    unsigned int side_len = WIDTH > HEIGHT ? HEIGHT : WIDTH;
    s->size = 0;
    switch (choix_pos_depart)
    {
        case 0:
            for(int i=0; i<HEIGHT; i++)
                add_pos_in_set(s, i*WIDTH);
            break;
    
        case 1:
            for(unsigned int i=1; i<side_len; i++)
                add_pos_in_set(s, i*WIDTH);
            break;
            
        case 2:
            while (ligne<h)
            {
                for (unsigned int i=0; i<(ligne+1); i++)
                {
                    unsigned int ajout_idx = (ligne*WIDTH)+h+i;
                    add_pos_in_set(s, ajout_idx);
                }
                ligne++;
            }
            while (ligne<(2*h))
            {
                for (unsigned int j=(ligne-h); j<h; j++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+j);
                    add_pos_in_set(s, ajout_idx);
                }
                ligne++;
            }
            break;

        default:
            break;
    }
     
}


void init_set_p1(unsigned int choix_pos_depart, struct set *s)
{
    unsigned int taille = tailles();
    unsigned int h = haut(taille);
    unsigned int ligne = 2*h+1;
    unsigned int side_len = WIDTH > HEIGHT ? HEIGHT : WIDTH;
    s->size = 0;
    switch (choix_pos_depart)
    {
        case 0:
            for(int i= 0; i<HEIGHT; i++)
                add_pos_in_set(s, WIDTH-1 + i*WIDTH);
            break;

        case 1:
            for(unsigned int i=1; i<side_len; i++)
                add_pos_in_set(s, i);
            break;

        case 2:
            while (ligne<((3*h)+1))
            {
                for (unsigned int p=0; p<=(ligne-(2*h+1)); p++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+(3*h)+1+p);
                    add_pos_in_set(s, ajout_idx);
                }
                ligne++;
            }
            while (ligne<=(4*h))
            {
                for (unsigned int t=0; t<(h-(ligne-(3*h+1))); t++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+taille-1-h-t);
                    add_pos_in_set(s, ajout_idx);
                }
                ligne++;
            }
            break;
    
        default:
            break;
    }
}



void world_depart(unsigned int choix_pos_depart, struct world_t *w, struct set *current_pos_p0, struct set *current_pos_p1)
{
    unsigned int taille = tailles();
    unsigned int h = haut(taille);
    unsigned int ligne = 0;

    switch (choix_pos_depart)
    {
        case 0: // les positions de départ sont sur les colonnes extremales (plateau rectangulaire: seed = 0)
            if(HEIGHT<= 4)
            {
                for (unsigned int k=0; k<(current_pos_p0->size); k++)
                {
                    world_set(w, current_pos_p0->positions[k],1);
                    world_set_sort(w, current_pos_p0->positions[k], 1);
                }
                for (unsigned int i=0; i<(current_pos_p1->size); i++)
                {
                    world_set(w, current_pos_p1->positions[i], 2);
                    world_set_sort(w, current_pos_p1->positions[i], 1);
                }
            }
            else 
            {
                world_set(w, 0,1);
                world_set_sort(w, 0, 2);
                world_set(w, WIDTH,1);
                world_set_sort(w, WIDTH, 3);
    
                world_set(w, (WORLD_SIZE-WIDTH),1);
                world_set_sort(w, (WORLD_SIZE-WIDTH), 2);
                world_set(w, (WORLD_SIZE-2*WIDTH),1);
                world_set_sort(w, (WORLD_SIZE-2*WIDTH), 3);
                for(unsigned int k = 2; k< (current_pos_p0->size) -2  ; k++)
                {
                    world_set(w, current_pos_p0->positions[k],1);
                    world_set_sort(w, current_pos_p0->positions[k], 1);
                }

                world_set(w, WIDTH-1,2);
                world_set_sort(w,  WIDTH-1, 2);
                world_set(w, 2*WIDTH-1,2);
                world_set_sort(w, 2*WIDTH-1, 3);
    
                world_set(w, (WORLD_SIZE -1),2);
                world_set_sort(w, (WORLD_SIZE-1), 2);
                world_set(w, (WORLD_SIZE-WIDTH-1),2);
                world_set_sort(w, (WORLD_SIZE-WIDTH-1), 3);
                for(unsigned int k = 2; k< (current_pos_p0->size) -2  ; k++)
                {
                    world_set(w, current_pos_p1->positions[k],2);
                    world_set_sort(w, current_pos_p1->positions[k], 1);
                }
            }
            break;

        
        case 1:
        {
            unsigned int len;
            if(WIDTH<=HEIGHT)
               len = WIDTH;
            else 
                len = HEIGHT;
                
            if (len<=4)
            {
                for (unsigned int k=1; k<len; k++)
                {
                    world_set(w, k, 2);
                    world_set_sort(w, k, 1);
                }
                for (unsigned int k = WIDTH; k<= WIDTH*(len-1)  ; k+=WIDTH)
                {
                    world_set(w, k, 1);
                    world_set_sort(w, k, 1);
                }
            }
            else
            {
                world_set(w, 1, 2);
                world_set_sort(w, 1, 2);
                world_set(w, 2, 2);
                world_set_sort(w, 2, 3);
                world_set(w,len-1,2);
                world_set_sort(w, len-1, 2);
                world_set(w,len-2,2);
                world_set_sort(w, len-2, 3);
                for (unsigned int k = 2; k<((current_pos_p0->size)-2)  ; k++)
                {
                    world_set(w, current_pos_p0->positions[k],1);
                    world_set_sort(w, current_pos_p0->positions[k], 1);
                }

                world_set(w,WIDTH,1);
                world_set_sort(w, WIDTH, 2);
                world_set(w,WIDTH*2,1);
                world_set_sort(w, WIDTH*2, 3);
                world_set(w,WIDTH*(len-1),1);
                world_set_sort(w, WIDTH*(len-1), 2);
                world_set(w,WIDTH*(len-2),1);
                world_set_sort(w, WIDTH*(len-2), 3);
                for(unsigned int k = 2; k< ((current_pos_p0->size)-2)  ; k++)
                {
                    world_set(w, current_pos_p1->positions[k],2);
                    world_set_sort(w, current_pos_p1->positions[k], 1);
                }
            }
            break;
        }
                
        case 2:
            while (ligne<h)
            {
                for (unsigned int i=0; i<(ligne+1); i++)
                {
                    unsigned int ajout_idx = (ligne*WIDTH)+h+i;
                    world_set(w,ajout_idx,1);
                    world_set_sort(w, ajout_idx, 1);
                }
                ligne++;
            }
            while (ligne<(2*h))
            {
                for (unsigned int j=(ligne-h); j<h; j++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+j);
                    world_set(w,ajout_idx,1);
                    world_set_sort(w, ajout_idx, 1);
                }
                ligne++;
            }
            ligne = 2*h+1;
            while (ligne<((3*h)+1))
            {
                for (unsigned int p=0; p<=(ligne-(2*h+1)); p++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+(3*h)+1+p);
                    world_set(w,ajout_idx,2);
                    world_set_sort(w, ajout_idx, 1);
                }
                ligne++;
            }
            while (ligne<=(4*h))
            {
                for (unsigned int t=0; t<(h-(ligne-(3*h+1))); t++)
                {
                    unsigned int ajout_idx = ((ligne*WIDTH)+taille-1-h-t);
                    world_set(w,ajout_idx,2);
                    world_set_sort(w, ajout_idx, 1);
                }
                ligne++;
            }    
            if(h>=2)
            { 
                    world_set(w,h,1);
                    world_set_sort(w, h, 2);
                    world_set(w,h+WIDTH,1);
                    world_set_sort(w, h+WIDTH, 3);
                    world_set(w,h+WIDTH+1,1);
                    world_set_sort(w, h+WIDTH+1, 3);

                    world_set(w,h*WIDTH,1);
                    world_set_sort(w, h*WIDTH, 2);
                    world_set(w,h*WIDTH+1,1);
                    world_set_sort(w, h*WIDTH+1, 3);
                    world_set(w,h*WIDTH+WIDTH+1,1);
                    world_set_sort(w, h*WIDTH+WIDTH+1, 3);

                    world_set(w, (taille-1)*WIDTH+taille-1-h,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-1-h, 2);
                    world_set(w,(taille-1)*(WIDTH)+taille-1-WIDTH-h,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-1-WIDTH-h, 3);
                    world_set(w, (taille-1)*(WIDTH)+taille-WIDTH-h-2,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-WIDTH-h-2, 3);

                    world_set(w, (taille-1)*(WIDTH)+taille-1-h*WIDTH,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-1-h*WIDTH, 2);
                    world_set(w, (taille-1)*(WIDTH)+taille-1-h*WIDTH-1,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-1-WIDTH*h-1, 3);
                    world_set(w, (taille-1)*(WIDTH)+taille-1-WIDTH*h-WIDTH-1,2);
                    world_set_sort(w, (taille-1)*(WIDTH)+taille-1-WIDTH*h-WIDTH-1, 3);
            }
            break;
    } 
}