#ifndef _PRISON_H
#define _PRISON_H

#include"game_randoms.h"


struct prisonnier {
    unsigned int type_piece;
    unsigned int equipe;
    unsigned int idx_capture;
};


struct prison {
    struct prisonnier cellule[2*MAX_SET_SIZE];
    unsigned int size; 
};


struct prison* init_prison();


void print_prison(struct prison *prison);


/** Fonction qui modifie le struct prison en emprisonnant une piece*/
void emprisonne(struct prison *prison, unsigned int idx, struct world_t *w);


/** Fonction qui modifie le struct prison en liberant une piece et qui la remet dans le world*/
void evasion(struct prison *prison, unsigned int idx, struct world_t *w);


#endif