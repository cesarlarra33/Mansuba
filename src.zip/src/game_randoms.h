#ifndef __RANDOMS_H__
#define __RANDOMS_H__

#include "init_game.h"


/** Returns 0 or 1 randomly, corresponding to victory type chosen for the current game. 
0 -> simple victoy
1 -> complex victory
 */
unsigned int get_random_victory_type();


/** Returns an integrer corresponding to the relation set for the next game (between 0 and 2 here)*/
unsigned int get_random_seed();


/** Returns 0 or 1 randomly, corresponding to the current player */
unsigned int get_random_player();


/** returns the next player */
unsigned int next_player(unsigned int current_player);


/** vérifie si le pion en idx est positionné sur une case de départ du joueur ennemi */
unsigned int dans_pos_dep(unsigned int choice, unsigned int idx_pion,unsigned int player);


/** Returns an integer between 0 to WORLD_SIZE-1 randomly, corresponding to the current player's piece which will be moved. The color of the case should correspond to the right player. */
unsigned int get_random_piece(unsigned int choice, unsigned int player, struct set* s0, struct set* s1, unsigned int victory_type);


/**return 0 ou 1 en fonction de si une évasion est reussie ou non, avec 50% de chances.*/
unsigned int escape();


#endif // __RANDOMS_H__