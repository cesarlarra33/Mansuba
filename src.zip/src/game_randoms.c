#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "game_randoms.h"


/** Return 0 or 1 randomly, corresponding to victory type chosen for the current game.
0 -> simple victoy
1 -> complexe victory
UPDATE : la fonction ne sert plus car on utilise maintenant le choix de l'utilisateur (ou victoire simple par defaut si pas de demande de l'utilisateur)
*/
unsigned int get_random_victory_type()
{
  return rand()%2;
}


unsigned int get_random_seed()
{
  if (HEIGHT>=5 && WIDTH>=5)
    return rand()%3;
  else
    return rand()%2;
}


unsigned int get_random_player()
{
  return rand()%2;
}


unsigned int next_player(unsigned int current_player)
{
  if (current_player == 0)
    return 1;
  else
    return 0;
}


unsigned int dans_pos_dep(unsigned int choice, unsigned int idx_pion,unsigned int player)
{
  if (player==0)
  {
    struct set pos_depart_j1;
    init_set_p1(choice, &pos_depart_j1);
    for (unsigned int i=0; i<pos_depart_j1.size; i++)
    {
      if (idx_pion==pos_depart_j1.positions[i])
        return 1;
    }
    return 0;
  }
  else if (player==1)
  {
    struct set pos_depart_j0;
    init_set_p0(choice, &pos_depart_j0);
    for (unsigned int i=0; i<pos_depart_j0.size; i++)
    {
      if (idx_pion==pos_depart_j0.positions[i])
        return 1;
    }
    return 0;
  }
  return 0;
}


unsigned int get_random_piece(unsigned int choice, unsigned int player, struct set* s0, struct set* s1, unsigned int victory_type)
{
  if (player==0)
  {
    if (victory_type==0) // victoire simple
    {
      unsigned int size_0 = s0->size;
      unsigned int posi = rand()%size_0;
      return s0->positions[posi];
    }
    else if (victory_type==1) // victoire complexe
    {
      unsigned int size_0 = s0->size;
      unsigned int posi = rand()%size_0;
      unsigned int idx_pion = s0->positions[posi];
      if (dans_pos_dep(choice,idx_pion,player)==1)
        return get_random_piece(choice,player,s0,s1,victory_type);
      else
        return idx_pion;
    }
  }
  else if (player==1)
  {
    if (victory_type==0)
    {
      unsigned int size_1 = s1->size;
      unsigned int posi;
      if (size_1!=0)
        posi = rand()%size_1;
      else
        posi=0;
      return s1->positions[posi];
    }
    else if (victory_type==1)
    {
      unsigned int size_1 = s1->size;
      unsigned int posi = rand()%size_1;
      unsigned int idx_pion = s1->positions[posi];
      if (dans_pos_dep(choice,idx_pion,player)==1)
        return get_random_piece(choice,player,s0,s1,victory_type);
      else
        return idx_pion;
    }
  }
  return 0;
}


unsigned int escape()
{
  return rand()%2;
}