#ifndef _VICTORY_H
#define _VICTORY_H

#include "init_game.h"


int condition_victoire_simple(unsigned int choix_pos_depart, struct set *s0, struct set *s1);

int condition_victoire_complexe(unsigned int choix_pos_depart, struct set *s0, struct set *s1);

int victoire(unsigned int choix_pos_depart, int type_victoire, struct set *s0, struct set *s1);


#endif