#include <stdio.h>

#include "positions.h"

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"


void add_pos_in_set(struct set* s, unsigned int idx)
{
  s->positions[s->size]=idx;
  s->size += 1;
}


void remove_pos_in_set(struct set* s, unsigned int idx)
{
  for (unsigned int k=0; k<(s->size); k++)
  {
    if (s->positions[k]==idx)
    {
      s->positions[k]=(s->positions[(s->size)-1]);
      s->size -= 1;
      break;
    }
  }
}


void print_current_pos(unsigned int player, struct set *current_pos)
{
  printf("current_pos joueur %d :", player);
  for (unsigned int j=0; j<(current_pos->size); ++j)
      printf("%u ", current_pos->positions[j]);
  printf("\n");
}


void print_set(struct set *set)
{
  for (unsigned int j=0; j<set->size; ++j)
      printf("%u ", set->positions[j]);
  printf("\n");
}


unsigned int tailles()
{
  // On cherche la taille max du plateau étoilé que l'on peut entrer dans le plateau carré HEIGHT*WIDTH
  unsigned int len = WIDTH >= HEIGHT ? HEIGHT : WIDTH;
  unsigned int taille;
  switch (len%4)
  {
    case 1:
      taille = len;
      break;
    case 0:
      taille = len-3;
      break;
    case 2:
      taille = len-1;
      break;
    case 3:
      taille = len-2;
      break;
  }
  return taille;
}


unsigned int haut(unsigned int taille)
{
  // Hauteur coin de l'étoile
  return (taille-1)/4;
}


struct idx_poss* idx_possi(struct idx_poss* idx_possibles)
{
  idx_possibles->size = 0;
  // On cherche la taille max du plateau étoilé que l'on peut entrer dans le plateau carré HEIGHT*WIDTH
  unsigned int taille = tailles();

  // Hauteur coin de l'étoile
  unsigned int h = haut(taille);
 
  // on créé un tableau des positions possibles : 
  unsigned int ligne = 0;
  while (ligne<h)
  {
    for (unsigned int i=0; i<(ligne+1); i++)
    {
      unsigned int ajout_idx = (ligne*WIDTH)+h+i;
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    ligne++;
  }
  while (ligne<(2*h))
  {
    for (unsigned int j=(ligne-h); j<h; j++)
    {
      unsigned int ajout_idx = ((ligne*WIDTH)+j);
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    for (unsigned int m=h; m<=(3*h); m++)
    {
      unsigned int ajout_idx = ((ligne*WIDTH)+m);
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    ligne++;
  }
  for (unsigned int o=h; o<=(3*h); o++)
  {
    unsigned int ajout_idx = ((ligne*WIDTH)+o);
    idx_possibles->tab[idx_possibles->size] = ajout_idx;
    idx_possibles->size++;
  }
  ligne++;

  while (ligne<((3*h)+1))
  {
    for (unsigned int p=0; p<=(ligne-(2*h+1)); p++)
    {
      unsigned int ajout_idx = ((ligne*WIDTH)+(3*h)+1+p);
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    for (unsigned int q=h; q<=(3*h); q++)
    {
      unsigned int ajout_idx = ((ligne*WIDTH)+q);
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    ligne++;
  }
  while (ligne<=(4*h))
  {
    for (unsigned int s=0; s<(h-(ligne-(3*h+1))); s++)
    {
      unsigned int ajout_idx = ((ligne*WIDTH)+taille-1-h-s);
      idx_possibles->tab[idx_possibles->size] = ajout_idx;
      idx_possibles->size++;
    }
    ligne++;
  }
  return idx_possibles;
}


/**Affiche le plateau de jeu au tour ou elle est appelée*/
void affiche_plateau(unsigned int seed, struct world_t *world)
{
  int c;
  int l;
  int piece;
  unsigned int len = WIDTH > HEIGHT ? HEIGHT : WIDTH; 
  unsigned int idx_possibles[WORLD_SIZE]; 
  unsigned int taille_idx_possibles = 0;    
  unsigned int i = len;
  switch (seed)
  {
    case 0:
    {
      printf("\n   ");
      for (c=1; c <= WIDTH; c++)
        printf("  %d ", c);
      printf("\n");
      printf("   +");
      for (c=1; c <= WIDTH; c++)
        printf("---+");
      printf("\n");
      for (l=HEIGHT; l > 0; l--)
      {
        printf(" %d |", HEIGHT-l+1);
        for (c=0; c < WIDTH; c++)
        {
          unsigned int u = world_get_sort(world, c+(l-1)*WIDTH); 
          unsigned int v = world_get(world, c+(l-1)*WIDTH);
          if (u==0)
            printf(" %c |", ' ');
          else      
          {
            switch (u)
            {
              case 1:
                piece = 'P';
                break;
              case 2:
                piece = 'T';
                break; 
              case 3: 
                piece = 'E';
                break;
              default:
                break;
            }
            if(v==1)
              printf(" %s%c%s |",KBLU, piece, KNRM); // joueur 1 : bleu               
            else if(v==2)
              printf(" %s%c%s |",KRED, piece, KNRM); // joueur 2 : rouge
          }
        }
        printf("\n");
        printf("   +");
        for (c=1; c <= WIDTH; c++)
          printf("---+");
        printf("\n");
      }
      printf("\n");
      break;
    }

    case 1:
    {
      for (unsigned int k=0; k<=(WIDTH*(len-1)); k+=WIDTH)
      {
        unsigned int j=0;
        while(j<i)
        {
          idx_possibles[taille_idx_possibles]= j+k;
          taille_idx_possibles++;
          j++;
        }
        i--;
      }
      printf("\n   ");
      for (c=1; c <= WIDTH; c++)
        printf("  %d ", c);
      printf("\n");
      printf("   +");
      for (c=1; c <= WIDTH; c++)
        printf("---+");
      printf("\n");
      for (l=HEIGHT; l > 0; l--)
      {
        printf(" %d |", HEIGHT-l+1);
        for (c=0; c < WIDTH; c++)
        {
          unsigned int u = world_get_sort(world, c+(l-1)*WIDTH); 
          unsigned int v = world_get(world, c+(l-1)*WIDTH);
          if (u==0 && dans_liste(idx_possibles,taille_idx_possibles,c+(l-1)*WIDTH)==1)
            printf(" %c |", ' ');
          else if (u==0 && dans_liste(idx_possibles,taille_idx_possibles,c+(l-1)*WIDTH)==0)
            printf(" %c |", 'X');
          else      
          {
            switch (u)
            {
              case 1:
                piece = 'P';
                break;
              case 2:
                piece = 'T';
                break; 
              case 3: 
                piece = 'E';
                break;
              default:
                break;
            }
            if (v!=0 && dans_liste(idx_possibles,taille_idx_possibles,c+(l-1)*WIDTH)==0)
              printf(" %s%c%s |",KGRN, piece, KNRM); // pieces vertes si pas dans le plateau
            else if (v==1)
              printf(" %s%c%s |",KBLU, piece, KNRM); // joueur 1 : bleu
            else if(v==2)
              printf(" %s%c%s |",KRED, piece, KNRM); // joueur 2 : rouge
          }
        }
        printf("\n");
        printf("   +");
        for (c=1; c <= WIDTH; c++)
          printf("---+");
        printf("\n");
      }
      printf("\n");
      break; 
    }

    case 2:
    {
      struct idx_poss p;
      struct idx_poss* idx_possibles = idx_possi(&p);
      printf("\n   ");
      for (c=1; c <= WIDTH; c++)
        printf("  %d ", c);
      printf("\n");
      printf("   +");
      for (c=1; c <= WIDTH; c++)
        printf("---+");
      printf("\n");
      for (l=HEIGHT; l > 0; l--)
      {
        printf(" %d |", HEIGHT-l+1);
        for (c=0; c < WIDTH; c++)
        {
          unsigned int u = world_get_sort(world, c+(l-1)*WIDTH); 
          unsigned int v = world_get(world, c+(l-1)*WIDTH);
          if (u==0 && dans_liste(idx_possibles->tab,idx_possibles->size,c+(l-1)*WIDTH)==1)
            printf(" %c |", ' ');
          else if (u==0 && dans_liste(idx_possibles->tab,idx_possibles->size,c+(l-1)*WIDTH)==0)
            printf(" %c |", 'X');
          else      
          {
            switch (u)
            {
              case 1:
                piece = 'P';
                break;
              case 2:
                piece = 'T';
                break; 
              case 3: 
                piece = 'E';
                break;
              default:
                break;
            }
            if (v!=0 && dans_liste(idx_possibles->tab,idx_possibles->size,c+(l-1)*WIDTH)==0)
              printf(" %s%c%s |",KGRN, piece, KNRM); // pieces vertes si pas dans le plateau
            else if(v==1)
              printf(" %s%c%s |",KBLU, piece, KNRM); //  joueur 1 : bleu
            else if(v==2)
              printf(" %s%c%s |",KRED, piece, KNRM); //  joueur 2 : rouge 
          }
        }
        printf("\n");
        printf("   +");
        for (c=1; c <= WIDTH; c++)
          printf("---+");
        printf("\n");
      }
      printf("\n");
      break;
    }
  }   
}


/** Teste si idx est dans tab[] */
int dans_liste(unsigned int tab[],unsigned int len,unsigned int idx)
{
  for (unsigned int k=0;k<len;++k)
    {
      if (tab[k]==idx)
          return 1;
    }
  return 0;
}