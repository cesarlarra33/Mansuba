#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <limits.h>

#include <getopt.h>
#include <math.h>

#include "prison.h"
#include "movements.h"
#include "victory.h"



void game(int MAX_TURN, int rand, unsigned int type_victoire)
{
  
  srand(rand); //initialise le générateur aléatoire

  // The victory type :
  print_type_vict(type_victoire);

  // We set the seed (relations between the different places):
  unsigned int seed = get_random_seed();
  print_type_game_board(seed);
  printf("\n");

  // initialisations for the game
  
  unsigned int choix_pos_depart = seed; // Un type unique de position de départ par type de plateau pour le moment
  
  // Initialisations of the players' sets (depends on choix_pos_depart which depends of the seed)
  struct set current_pos_p0;
  init_set_p0(choix_pos_depart, &current_pos_p0);
  struct set current_pos_p1;
  init_set_p1(choix_pos_depart, &current_pos_p1);

  printf("Sets de départ:\n");
  print_set(&current_pos_p0);
  print_set(&current_pos_p1);
  printf("\n");

  // Initialisation of the world 
  struct world_t* w = world_init();
  world_depart(choix_pos_depart, w, &current_pos_p0, &current_pos_p1); 

  //Initialisation of the prison
  struct prison* prison = init_prison();
  
  // random choice of the first player to play
  enum color_t current_player = get_random_player();

  // Victory type
  unsigned int v = victoire(choix_pos_depart,type_victoire,&current_pos_p0,&current_pos_p1);

  // To count the number of turns
  int n_tour = 0;

  affiche_plateau(seed, w);


  while (v==0 && n_tour<MAX_TURN)  
  {     
    n_tour ++;
    
    printf("\nTour N°%d\n", n_tour);
    print_current_pos(0, &current_pos_p0); // player p0's positions printed
    print_current_pos(1, &current_pos_p1); // player p1's positions printed
    printf("\n");
    print_prison(prison); // we print the prison content
    printf("\n");
    printf("current player : %d\n", current_player); // prints who's going to play the next turn

    if (current_player==0)
    {
      unsigned int p = get_random_piece(choix_pos_depart, current_player, &current_pos_p0, &current_pos_p1, type_victoire);
      printf("get_random_piece renvoie : %u\n", p); // print pour avoir un visuel du jeu

      if (world_get(w,p)==0)
        evasion(prison, p, w);
      else
      {
        unsigned int next_p = next_pos_piece(seed, p, w, &current_pos_p0, &current_pos_p1);
        printf("next_pos = %u\n", next_p);
        if(next_p!=UINT_MAX && world_get(w, next_p)==2)
        {
          emprisonne(prison, next_p, w);
          move_piece(p,next_p,current_player, &current_pos_p0, &current_pos_p1,w);
        }
        else if (next_p!=UINT_MAX && world_get(w, next_p)!=1)
          move_piece(p,next_p,current_player, &current_pos_p0, &current_pos_p1,w);
      }
    }

    else if (current_player==1)
    {
      unsigned int p = get_random_piece(choix_pos_depart, current_player, &current_pos_p0, &current_pos_p1, type_victoire);
      //printf("get_random_piece renvoie : %u\n", p); // print pour avoir un visuel du jeu
      
      if (world_get(w, p)==0)
        evasion(prison, p, w);
      else
      {
        unsigned int next_p = next_pos_piece(seed, p, w, &current_pos_p1, &current_pos_p0);
        //printf("next_pos = %u\n", next_p);
        if(next_p!=UINT_MAX && world_get(w, next_p)==1)
        {
          emprisonne(prison, next_p, w);
          move_piece(p,next_p,current_player, &current_pos_p0, &current_pos_p1,w);
        }
        else if (next_p!=UINT_MAX && world_get(w, next_p)!=2)
          move_piece(p,next_p,current_player, &current_pos_p0, &current_pos_p1,w);
      }
    }

    current_player = next_player(current_player);
    v = victoire(choix_pos_depart,type_victoire,&current_pos_p0,&current_pos_p1);

    affiche_plateau(seed, w);

    double max_turn = (double) MAX_TURN;
    int t = (int) floor(sqrt(max_turn));
    //printf("racine de MAX_TURN = %d\n",t);
    if (n_tour%t==0)
    {
      seed = get_neighbors_seed(seed);
      choix_pos_depart = seed;
    }
    printf("Seed : %u\n",seed);
  }
    
  /* En cas de victoire, on annonce le gagnant */
  print_type_vict(type_victoire);
  if ( v == 1 )
    printf("Le joueur n°1 a gagné ! Le joueur n°2 a perdu...\n\n");
  else if ( v == 2 )
    printf("Le joueur n°2 a gagné ! Le joueur n°1 a perdu...\n\n");
  else if (v == 0)
    printf("Nombre maximal de tours atteint, aucun joueur n'a gagné...\n\n");
 
}



int main(int argc, char* argv[])
{
  int MAX_TURN = 50; // nombre de tours maximal par defaut
  unsigned int type_victoire = 0; // victoire simple par défaut
  int rand = 0; // valeur à mettre dans srand 
  
  int opt;
   
  while((opt = getopt(argc, argv, "s:m:t:")) != -1)
  {
    switch(opt)
    {
      case 'm':
        printf("option MAX_TURN: %s\n", optarg);
        MAX_TURN = atoi(optarg);
        break;

      case 't':
        printf("option victory type: %s\n", optarg);
        if (optarg[0] =='c')
          type_victoire = 1;
        else if (optarg[0] == 's')
          type_victoire = 0;
        break;

      case 's':
        printf("valeur pour le srand: %s\n", optarg);
        rand = atoi(optarg);
        break;
        
      default :
        break;
    }
  }

  game(MAX_TURN, rand, type_victoire);
  return 0;
}