#include <stdio.h>
#include <stdlib.h>

#include "victory.h"



int condition_victoire_simple(unsigned int choix_pos_depart, struct set *s0, struct set *s1)
{
    // we first check if player 0 has won the game
    struct set pos_depart_j1;
    init_set_p1(choix_pos_depart, &pos_depart_j1);
    for(unsigned int i = 0; i < s0->size; i++)
    {
        for(unsigned int j = 0; j<pos_depart_j1.size; j++)
        {
            if(s0->positions[i]==pos_depart_j1.positions[j])
                return 1;  // player 0 has won
        }
    }
    // we now check if player 1 has won the game
    struct set pos_depart_j0;
    init_set_p0(choix_pos_depart, &pos_depart_j0);
    for(unsigned int j =0; j<s1->size; j++)
    {
        for(unsigned int i =0; i<pos_depart_j0.size; i++)
        {
            if(s1->positions[j]==pos_depart_j0.positions[i])
                return 2; // player 1 has won 
        }
    }
    return 0;
} 


int condition_victoire_complexe(unsigned int choix_pos_depart, struct set *s0, struct set *s1)
{
    // we first check if player 0 has won the game
    struct set pos_depart_j1;
    init_set_p1(choix_pos_depart, &pos_depart_j1);
    unsigned int compt0 = 0;
    
    for(unsigned int i = 0; i < s0->size; i++)
    {
        for(unsigned int j = 0; j<pos_depart_j1.size; j++)
        {
            if(s0->positions[i]==pos_depart_j1.positions[j])
                compt0++;  
        }
    }
    if (compt0 == s0->size)
        return 1;

    // we now check if player 1 has won the game
    unsigned int compt1 = 0;
    struct set pos_depart_j0;
    init_set_p0(choix_pos_depart, &pos_depart_j0);
    for(unsigned int j =0; j<s1->size; j++)
    {
        for(unsigned int i =0; i<pos_depart_j0.size; i++)
        {
            if(s1->positions[j]==pos_depart_j0.positions[i])
                compt1++;
        }
    }
        if (compt1 == s1->size)
            return 2;
    return 0;
} 


int victoire(unsigned int choix_pos_depart, int type_victoire, struct set *s0, struct set *s1)
{
    int a;
    switch (type_victoire)
    {
        case 0:
            a = condition_victoire_simple(choix_pos_depart, s0, s1);
            break;
        
        case 1:
            a = condition_victoire_complexe(choix_pos_depart, s0, s1);
            break;

        default:
            break;
    }
    return a;
}