#include<stdio.h>
#include<stdlib.h>

#include"prison.h"


struct prison cage;

struct prison* init_prison()
{
    for (unsigned int i=0; i<2*MAX_SET_SIZE; i++)
    {
        cage.cellule[i].equipe=0;
        cage.cellule[i].type_piece=0;
        cage.cellule[i].idx_capture=0;
    }
    cage.size=0;
    return &cage;
}


void print_prison(struct prison* prison)
{
    if ((prison->size)>0)
    {
        for (unsigned int k=0; k<(prison->size); k++)
            printf("Le joueur %u a une pièce de type %u capturée en idx=%u \n", (prison->cellule[k].equipe)-1, prison->cellule[k].type_piece, prison->cellule[k].idx_capture);
    }
    else 
        printf("La prison est vide. \n");
}


/**fonction qui emprisonne une piece en stockant sa nature, sa couleur, et la case sur laquelle elle a été capturée.*/
void emprisonne(struct prison *prison, unsigned int idx, struct world_t *w)
{
    prison->cellule[prison->size].type_piece = world_get_sort(w, idx);
    prison->cellule[prison->size].equipe = world_get(w, idx);
    prison->cellule[prison->size].idx_capture = idx;
    prison->size += 1;
    printf("la piece du joueur %u en case %u a été emprisonnée\n", world_get(w, idx)-1, idx);
}


/**fonction qui donne la possibilité à une pièce emprisonnée de s'évader avec une probabilité 1/2*/
void evasion(struct prison *prison, unsigned int idx, struct world_t *w)
{
    printf("La pièce ayant été emprisonée en case %u tente de s'échapper\n", idx);
    int reussite = escape();
    if (reussite==1)
    {
        int i = 0;
        while(idx != prison->cellule[i].idx_capture)
            i++;
        world_set(w,idx,prison->cellule[i].equipe);
        //printf("equipe : %u\n", prison->cellule[i].equipe);
        world_set_sort(w,idx,prison->cellule[i].type_piece);
        
        //pour remplir la cellule vidée dans la prison, on y met le prisonnier de la derniere cellule.
        prison->cellule[i].type_piece = prison->cellule[prison->size-1].type_piece;
        prison->cellule[i].equipe = prison->cellule[prison->size-1].equipe;
        prison->cellule[i].idx_capture = prison->cellule[prison->size-1].idx_capture;

        prison->size -= 1;
        printf("Son évasion a réussit, bravo ! Elle revient sur le plateau de jeu là où elle fut emprisonnée.\n");
    }
    else
        printf("oups, raté...\n");   
}