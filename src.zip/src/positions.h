#ifndef _POSITIONS_H
#define _POSITIONS_H

#include "world.h"
 
#define MAX_SET_SIZE 16

struct set
{ 
        unsigned int positions[MAX_SET_SIZE];
        unsigned int size;  
};


struct idx_poss
{
        unsigned int tab[WORLD_SIZE];
        unsigned int size;
};


void add_pos_in_set(struct set* s, unsigned int idx);

void remove_pos_in_set(struct set* s, unsigned int idx);


void print_current_pos(unsigned int player, struct set *current_pos);

void print_set(struct set *set);


unsigned int tailles();

unsigned int haut(unsigned int taille);

struct idx_poss* idx_possi (struct idx_poss* idx_possibles);


void affiche_plateau(unsigned int seed, struct world_t *world);

/** renvoie 1 si idx est dans la liste tab de taille len, et 0 sinon */
int dans_liste(unsigned int tab[],unsigned int len,unsigned int idx);


#endif