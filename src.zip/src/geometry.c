#include <stdio.h>
#include <string.h>

#include "geometry.h"



/** Return a string describing the color `c` and sort `s` */
const char* place_to_string(enum color_t c, enum sort_t s)
{
    char *couleurs[] = {"NO_COLOR", "BLACK","WHITE","MAX_COLOR"};
    char *sort[]= {"NO_SORT","PAWN","MAX_SORT"};
    char *color = couleurs[c];
    char *sorte = sort[s]; 
    static char concatenate[20];
    
    //concaténer les deux chaines
    unsigned long i = 0;
    while (i<strlen(color)) 
    {
        concatenate[i]=color[i];
        i++;
    }
    concatenate[i]=' ';
    i++;
    unsigned long j = 0 ;
   
    while(j<strlen(sorte))
    {
        concatenate[i+j]=sorte[j];
        j++;
    }
    concatenate[i+j]='\0';
    return(concatenate);
}


/** Return a string describing the direction `d` */
const char* dir_to_string(enum dir_t d)
{
    if (d<0)
        d = 4-d;
    char* directions[] = {"NO_DIR", "EAST", "NEAST", "NORTH", "NWEST", "WEST", "SWEST", "SOUTH", "SEAST", "MAX_DIR"};
    return(directions[d]);
}