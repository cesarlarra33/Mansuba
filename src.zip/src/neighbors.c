#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "neighbors.h"



/** Initializes the relation between the neighbors, based on an
    integer `seed`. `seed` must be less than MAX_RELATIONS.
    Can be called multiple times. */
unsigned int init_neighbors(unsigned int seed)
{
  unsigned int seed_precedent = seed;
  while (seed==seed_precedent)
    seed = get_random_seed();
  return seed;
  ///printf("SEED DE INIT_NEIGHBORS : %u\n\n", seed);
}


/** Returns the seed set by the latest call to `init_neighbors`. */
unsigned int get_neighbors_seed(unsigned int seed_precedent)
{
  unsigned int seed = init_neighbors(seed_precedent);
  //printf("SEED DE GET_NEIGHBOR_SEED : %u\n\n", seed);
  return seed;
}


/** Returns the neighbor of the place `idx`, in direction `d`, and
    UINT_MAX if there is no such neighbor (or any other kind of error) */
unsigned int get_neighbor(unsigned int seed, unsigned int idx, enum dir_t d)
{
  unsigned int len;
  int z;
  z= (int)idx;
  
  switch (seed)
  {
    case 0: // tableau rectangulaire basique
      if ( (idx==0 && d!=1 && d!=0 && d!=2 && d!= 3) || (idx==(WIDTH-1) && d!=0 && d!=-1 && d!=4 && d!=3) || (idx==(WORLD_SIZE-1) && d!=0 && d!=-3 && d!=-2 && d!=-1) || (idx==(WORLD_SIZE-WIDTH) && d!=0 && d!=-3 && d!=-4 && d!=1)) // les coins
	      return UINT_MAX;

      else if ( ((idx+WIDTH)>(WORLD_SIZE-1)) && (d==2||d==3||d==4) ) // idx sur ligne du haut + direction vers le haut
	      return UINT_MAX;

      else if ( ((z-(WIDTH-1))%(WIDTH)==0) && (d==1||d==2||d==-4) ) //colonne de droite + direction vers la droite
	      return UINT_MAX;

      else if ( (idx%(WIDTH)==0) && (d==4||d==-1||d==-2) ) //colonne de gauche + direction vers la gauche
	      return UINT_MAX;

      else if ( ((z-WIDTH)<0) && (d==-3||d==-4||d==-2) )  // idx sur ligne du bas + direction vers le bas
	      return UINT_MAX;

      else 
	      switch( d )
	        {
	        case 1:
	          return idx+1;
	          break;
	        case 2:
	          return idx+WIDTH+1;
	          break;
	        case 3:
	          return idx+WIDTH;
	          break;
      	  case 4:
	          return idx+WIDTH-1;
    	      break;
	        case -1:
	          return idx-1;
	          break;
	        case -2:
	          return idx-WIDTH-1;
	          break;
	        case -3:
	          return idx-WIDTH;
	          break;
      	  case -4:
	          return idx-WIDTH+1;
	          break;
	        case 0:
	          return idx;
	          break;
	        case 9:
	          return UINT_MAX;
	          break;
	        }
      break;


    case 1: // plateau en forme de triangle (hypothénus = diagonale haut-gauche à bas-droit du rectangle)

      // on détermine la longueur des cotés du plateau triangulaire
      len = WIDTH > HEIGHT ? HEIGHT : WIDTH;

      // on créé un tableau des positions possibles : 
      unsigned int idx_possibles[WORLD_SIZE]; 
      unsigned int taille_idx_possibles = 0;
      
      unsigned int i = len;
      for (unsigned int k=0; k<=(WIDTH*(len-1)); k+=WIDTH)
      { 
        unsigned int j=0;
        while(j<i)
        {
          idx_possibles[taille_idx_possibles]= j+k;
          taille_idx_possibles++;
          j++;
        }
        i--;
      }
      

      //on regarde les cas qui devront renvoyer UINT_MAX :
      if ( (idx==0 && d!=1 && d!=0 && d!= 3) || (idx==(len-1) && d!=0 && d!=-1 && d!=4) || (idx==(WIDTH*(len-1)) && d!=0 && d!=-3 && d!=-4)) // les 3 coins
        return UINT_MAX;

      else if (dans_liste(idx_possibles,taille_idx_possibles,idx)==0) // partie vide du plateau
        return UINT_MAX;

      else if ( (idx%(WIDTH)==0) && (d==4||d==-1||d==-2||d==2) ) //colonne de gauche + mauvaise direction
	      return UINT_MAX;

      else if ( ((z-WIDTH)<0) && (d==-3||d==-4||d==-2||d==2) )  // idx sur ligne du bas + mauvaise direction
        return UINT_MAX;

      else if (dans_liste(idx_possibles, taille_idx_possibles, idx)==1 && ((idx-len+1)%(WIDTH-1)==0) && (d!=-3 && d!=4 && d!=-4 && d!=-1)) // bord droit du triangle
        return UINT_MAX;

      else
      {
        switch (d)
        {
        case 2:
          return UINT_MAX;
          break;
        case -2:
          return UINT_MAX;
          break;
        case 1:
	          return idx+1;
	          break;
	      case 3:
	        return idx+WIDTH;
	        break;
      	case 4:
	        return idx+WIDTH-1;
    	    break;
	      case -1:
	        return idx-1;
	        break;
	      case -3:
	        return idx-WIDTH;
	        break;
    	  case -4:
          return idx-WIDTH+1;
          break;
	      case 0:
	        return idx;
	        break;
	      case 9:
          return UINT_MAX;
          break;
        }
      }
      break;


    case 2: // plateau triangulaire à bord étoilé (classique des dames chinoises)
    {
      struct idx_poss p;
      struct idx_poss* idx_possibles = idx_possi(&p);

      //on regarde les cas qui devront renvoyer UINT_MAX :
      if (dans_liste(idx_possibles->tab,idx_possibles->size,idx)==0) // partie vide du plateau
        return UINT_MAX;

      else
      {
        unsigned int idx_fin;
        switch (d)
        {
          case 2:
            idx_fin=idx+WIDTH+1;
            break;

          case -2:
            idx_fin=idx-WIDTH-1;
            break;

          case 1:
            idx_fin=idx+1;
            break;

          case 3:
            idx_fin=idx+WIDTH;
            break;

          case 4:
            idx_fin=idx+WIDTH-1;
            break;

          case -1:
            idx_fin=idx-1;
            break;

          case -3:
            idx_fin=idx-WIDTH;
            break;

          case -4:
            idx_fin=idx-WIDTH+1;
            break;

          case 0:
            idx_fin= idx;
            break;
      
          case 9:
            idx_fin= UINT_MAX;
            break;
        }
        if (dans_liste(idx_possibles->tab,idx_possibles->size,idx_fin)==0)
          return UINT_MAX;
        else
          return idx_fin;
      }
    break;
    }
  }
  printf("seed non reconnu");
  return UINT_MAX;
}



struct neighbors_t get_neighbors(unsigned int seed, unsigned int idx)
{
  struct neighbors_t neighbors_idx[MAX_NEIGHBORS];
  unsigned int k = 0;
  for (int i=-4; i<5; i++)
  {
    if (i!=0)
    {
      struct vector_t vect;
      vect.i=get_neighbor(seed, idx, i);
      vect.d=i;
      neighbors_idx->n[k]=vect;
      ++k;
    }
  }
  return *neighbors_idx;
}