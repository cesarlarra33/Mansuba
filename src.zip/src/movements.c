#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include <time.h>

#include "movements.h"


/* To print tab's elements */
void print_liste_pos(unsigned int tab[], int taille)
{
  for (int k=0; k<taille; k++)
    printf("%d  ", tab[k]);
  printf("\n");
}


// next position depending on the piece's type
unsigned int next_pos_piece(unsigned int seed, unsigned int idx, struct world_t *w, struct set *s_joueur, struct set *s_ennemi)
{
  switch (world_get_sort(w, idx))
  {
  case 1: // pawn
    return next_pos_pawn(seed, idx, s_joueur, s_ennemi);  
    break;
  case 2: // tower
    return next_pos_tower(seed, idx, w);
    break;
  case 3: // elephant
    return next_pos_elephant(seed, idx, w);
    break;
  default:
    return 0; 
    break;
  }
}

// next position for the tower
unsigned int next_pos_tower(unsigned int seed, unsigned int idx, struct world_t *w)
{
  unsigned int pos_possibles[WORLD_SIZE];
  int taille_pos_possibles = 0;
  for (int dir_card=-3; dir_card<4; dir_card += 2)
  {
    if ((dir_card==-3) && get_neighbor(seed, idx, -3)!= UINT_MAX) //SOUTH
    {
      unsigned int destination = idx;
      int k = 1; 
      while ((get_neighbor(seed, destination, -3)!= UINT_MAX) && (world_get(w, idx-k*WIDTH)==0))
      {
        destination = idx-k*WIDTH;
        k++; 
      }
      //on regarde si la case d'après celle où on s'est arreté est un ennemi, si oui on le mange.
      printf("%u\n", get_neighbor(seed, idx-(k-1)*WIDTH,-3));
      if (get_neighbor(seed, idx-(k-1)*WIDTH, -3)!=UINT_MAX && (world_get(w, idx-k*WIDTH)+world_get(w, idx))==3)
        destination = idx-k*WIDTH;
      pos_possibles[taille_pos_possibles]= destination;
      taille_pos_possibles++; 
    }
    else if ((dir_card==-1) && get_neighbor(seed, idx, -1)!= UINT_MAX) //WEST
    {
      unsigned int destination = idx;
      int k=1;
      while ((get_neighbor(seed, destination, -1)!= UINT_MAX) && (world_get(w, idx-k)==0))
      {
        destination = idx-k; 
        k++;
      }
      //on regarde si la case d'après celle où on s'est arreté est un ennemi, si oui on le mange.
      if (get_neighbor(seed, idx-(k-1), -1)!=UINT_MAX && world_get(w, idx-k)+ world_get(w, idx)==3)
        destination = idx-k ;

      pos_possibles[taille_pos_possibles]=destination;
      taille_pos_possibles ++;
    }
    else if ((dir_card==1) && get_neighbor(seed, idx, 1)!= UINT_MAX) //EAST
    {
      unsigned int destination = idx;
      int k=1; 
      while ((get_neighbor(seed, destination, 1)!=UINT_MAX) && (world_get(w, (idx+k))==0))
      {
        destination = idx+k; 
        k++;
      }
      //on regarde si la case d'après celle où on s'est arreté est un ennemi, si oui on le mange.
      if (get_neighbor(seed, idx+(k-1), 1)!=UINT_MAX && world_get(w, (idx+k))+world_get(w, idx)==3)
        destination = idx+k ;

      pos_possibles[taille_pos_possibles]=destination;
      taille_pos_possibles++;
    }
    else if ((dir_card==3) && get_neighbor(seed, idx, 3)!=UINT_MAX) //NORTH
    {
      unsigned int destination = idx;
      int k = 1;
      while ((get_neighbor(seed, destination, 3)!= UINT_MAX) && (world_get(w, idx+k*WIDTH)==0))
      {
        destination = idx+k*WIDTH;
        k++; 
      }
      //on regarde si la case d'après celle où on s'est arreté est un ennemi, si oui on le mange.
      if (get_neighbor(seed, idx+(k-1)*WIDTH, 3)!=UINT_MAX && world_get(w, idx+k*WIDTH)+ world_get(w, idx)==3)
        destination = idx + k*WIDTH;
      pos_possibles[taille_pos_possibles]=destination;
      taille_pos_possibles++; 
    }
  }
  // prints pour avoir un visuel du jeu :
  printf("On joue la pièce de position : %u\n", idx);
  printf("taille_pos_possible : %d\npositions : ", taille_pos_possibles);
  print_liste_pos(pos_possibles,taille_pos_possibles);
  if (taille_pos_possibles==0) // cas où le pion n'a pas de mouv possible
    return UINT_MAX;
  else
  {
    unsigned int case_choisie = rand()%(taille_pos_possibles);
    printf("case random choisie : %u\n", pos_possibles[case_choisie]); // print pour avoir un visuel du jeu
    return(pos_possibles[case_choisie]);
  }
}

// next position for the elephant
unsigned int next_pos_elephant(unsigned int seed, unsigned int idx, struct world_t *w)
{
  unsigned int pos_possibles[WORLD_SIZE];
  int taille_pos_possibles = 0; 
  unsigned int place1;
  unsigned int place2; 
  for(int i = -3; i<4; i+=2)
  {
    for(int j =-3; j<4;j+=2)
    {
      place1=get_neighbor(seed, idx,i);
      place2=get_neighbor(seed, place1,j);
      if((place1 != UINT_MAX)&&(place2!=UINT_MAX)&&(world_get(w,place2)!=world_get(w, idx))&&(place2!=idx)&&dans_liste(pos_possibles, taille_pos_possibles, place2)==0)
      {
        pos_possibles[taille_pos_possibles]=place2;
        taille_pos_possibles++;
      }
    }
  }
  // prints pour avoir un visuel du jeu :
  printf("On joue la pièce de position : %u\n", idx);
  printf("taille_pos_possible : %d\npositions : ", taille_pos_possibles);
  print_liste_pos(pos_possibles,taille_pos_possibles);
  if (taille_pos_possibles==0) // cas où le pion n'a pas de mouv possible
    return UINT_MAX;
  else
  {
    unsigned int case_choisie = rand()%(taille_pos_possibles);
    printf("case random choisie : %u\n", pos_possibles[case_choisie]); // print pour avoir un visuel du jeu
    return(pos_possibles[case_choisie]);
  }
}



//Returns a random movement from the liste of the possible movements of the piece at the place 'idx' (pour un pion)
unsigned int next_pos_pawn(unsigned int seed, unsigned int idx, struct set *s_joueur, struct set *s_ennemi)
{
  unsigned int pos_possibles[WORLD_SIZE];
  int taille_pos_possibles = 0;

  // on va chercher les voisins de idx
  struct neighbors_t neighbors = get_neighbors(seed, idx);

  // on parcours les voisins de idx
  for (int i = 0; i<MAX_NEIGHBORS; i++)
  {
    struct vector_t vect_voisine = neighbors.n[i]; // vecteur du ieme voisin de idx
    unsigned int case_voisine = vect_voisine.i;   // identifiant du ieme voisin de idx

    // prints pour debuguer 
    /*
    printf("\nvoisin %u, de direction %d\n",vect_voisine.i, vect_voisine.d);
    if (case_voisine!=UINT_MAX)
      printf("test 1 passed : case_voisine!=UINT_MAX\n");
    if (dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0)
      printf("test 2 passed : dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0\n");
    if (dans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==0)
      printf("test 3 passed : ans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==0\n");
    */

    //deplacements simple
    if((case_voisine!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0)/*&&(dans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==0)*/) 
    {
      pos_possibles[taille_pos_possibles]=case_voisine;
      taille_pos_possibles++;
    }

    //sauts 
    if ((case_voisine!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0)&&(dans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==1))
    {
      unsigned int direction_voisin = vect_voisine.d;
      unsigned int jumped_case = get_neighbor(seed, case_voisine,direction_voisin);
      int existence_ennemi = 1;
      int a = 0;
      while(a<WORLD_SIZE && existence_ennemi==1)
      {
        //on verifie que la case sur laquelle on saute est libre
        if ((jumped_case!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,jumped_case)==0)/*&&(dans_liste(s_ennemi->positions,s_ennemi->size,jumped_case)==0)*/&&(jumped_case!=idx))
        {
          existence_ennemi = 0;
          if (jumped_case!=UINT_MAX && dans_liste(pos_possibles,taille_pos_possibles,jumped_case)==0)
          {
            pos_possibles[taille_pos_possibles]=jumped_case;
            taille_pos_possibles++;
          }
          struct neighbors_t neighbors_mechants = get_neighbors(seed, jumped_case);
          for (int j=0; j<MAX_NEIGHBORS; j++)
          {
            struct vector_t vect_voisine = neighbors_mechants.n[j];
            unsigned int case_voisine = vect_voisine.i;
            int direction_voisin = vect_voisine.d;
            if ((case_voisine!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0)&&(dans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==1)&&(dans_liste(pos_possibles, taille_pos_possibles, get_neighbor(seed, case_voisine,direction_voisin))==0)&&(get_neighbor(seed, case_voisine,direction_voisin)!=idx))
            {
              existence_ennemi = 1;
              jumped_case = get_neighbor(seed, case_voisine,direction_voisin);
              if (jumped_case!=UINT_MAX && dans_liste(pos_possibles,taille_pos_possibles,jumped_case)==0 && (dans_liste(s_joueur->positions,s_joueur->size,jumped_case)==0)/*&&(dans_liste(s_ennemi->positions,s_ennemi->size,jumped_case)==0)*/&&(jumped_case!=idx))
              {
                pos_possibles[taille_pos_possibles]=jumped_case;
                taille_pos_possibles++;
              }
            }
          }
        }
        a++;
      }
    }
  }

  // prints pour avoir un visuel du jeu :
  printf("On joue la pièce de position : %u\n", idx);
  printf("taille_pos_possible : %d\npositions : ", taille_pos_possibles);
  print_liste_pos(pos_possibles, taille_pos_possibles);

  if (taille_pos_possibles==0) // cas où le pion n'a pas de mouv possible
    return UINT_MAX;
  else
  {
    unsigned int case_choisie = rand()%(taille_pos_possibles);
    printf("case random choisie : %u\n", pos_possibles[case_choisie]); // print pour avoir un visuel du jeu
    return(pos_possibles[case_choisie]);
  }
}


//une fonction qui modifie le world et les sets de chaque joueurs suite au mouvement d'une piece dans la partie.
void move_piece(unsigned int idx_depart, unsigned int idx_arrivee, unsigned int player, struct set* p0, struct set* p1, struct world_t *w)
{
  if (player==0)
  {
    remove_pos_in_set(p0, idx_depart);
    add_pos_in_set(p0, idx_arrivee);
    world_set(w, idx_depart, 0);
    world_set(w, idx_arrivee, 1);
  }
  else if (player==1)
  {
    remove_pos_in_set(p1, idx_depart);
    add_pos_in_set(p1, idx_arrivee);
    world_set(w,idx_depart,0);
    world_set(w, idx_arrivee,2);
  }    
  world_set_sort(w,idx_arrivee,world_get_sort(w, idx_depart));
  world_set_sort(w,idx_depart,0);
}