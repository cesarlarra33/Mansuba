#ifndef __MOVEMENTS_H__
#define __MOVEMENTS_H__

#include "neighbors.h"



/** permet d'afficher les éléments d'un tableau d'entier non signés (positions des pions dans un set par exemple). Prend également en argument la taille du tableau. */
void print_liste_pos(unsigned int tab[], int taille);

//next position en fct du type de pion
unsigned int next_pos_piece(unsigned int seed, unsigned int idx, struct world_t *w, struct set *s_joueur, struct set *s_ennemi);
  
/** Choisit aléatoirement la position suivante d'un pion parmi toutes celles possibles calculées*/
unsigned int next_pos_pawn(unsigned int seed, unsigned int idx, struct set *s_joueur, struct set *s_ennemi);

/** Choisit aléatoirement la position suivante d'une tour parmi toutes celles possibles calculées*/
unsigned int next_pos_tower(unsigned int seed, unsigned int idx, struct world_t *w);

/** Choisit aléatoirement la position suivante d'un elephant parmi toutes celles possibles calculées*/
unsigned int next_pos_elephant(unsigned int seed, unsigned int idx, struct world_t *w);

/** Effectue le déplacement du pion en modifiant les sets et le world */
void move_piece(unsigned int idx_depart, unsigned int idx_arrivee, unsigned int player, struct set* p0, struct set* p1, struct world_t *w);


#endif