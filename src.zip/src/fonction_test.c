#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "neighbors.h"
#include "movements.h"
#include "positions.h"

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"
/*
unsigned int next_pos(unsigned int idx, struct set *s_joueur, struct set *s_ennemi)
{
    int pos_possibles[WORLD_SIZE];
    int taille_pos_possibles = 0;

    init_neighbors(0);
    struct neighbors_t neighbors = get_neighbors(idx);

    for(int i =0; i <MAX_NEIGHBORS; i++)
    {
        struct vector_t vect_voisin = neighbors.n[i];
        unsigned int case_voisin = vect_voisin.i;
        unsigned int direction_voisin = vect_voisin.d;

        printf("la case que je regarde est la case %d\n", case_voisin);

        //deplacements simple
         if((case_voisin!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,case_voisin)==0)&&(dans_liste(s_ennemi->positions,s_ennemi->size,case_voisin)==0))
        {
            pos_possibles[taille_pos_possibles]=case_voisin;
            
            printf("j'ai ajouté %u à pos_possibles\n",pos_possibles[taille_pos_possibles]);
            
            taille_pos_possibles++;
        }

        //sauts simples ou multiples --> je regarde s'il y a un ennemi sur case voisine
        if((case_voisine!=UINT_MAX)&&(dans_liste(s_joueur->positions,s_joueur->size,case_voisine)==0)&&(dans_liste(s_ennemi->positions,s_ennemi->size,case_voisine)==1))
        {
            int existence_ennemi = 1;
            
            //je défini jumped_case comme etant la case où nous mene un saut par dessus un ennemi voisin dans la direction de ce dernier
            unsigned int jumped_case = get_neighbor(case_voisin, vect_voisin);

            printf("jumped case est %d\n", jumped_case);
            while(existence_ennemi==1)
            {
                existence_ennemi = 0; 
                
                
                //je regarde si jumped_case rempli les conditions necessaires à ce qu'on y saute
                if((jumped_case!=UINT_MAX)&&
                   (dans_liste(s_joueur->positions,s_joueur->size,jumped_case)==0)&&
                   (dans_liste(s_ennemi->positions,s_ennemi->size,jumped_case)==0)&&
                   (jumped_case!=idx)&&
                   (dans_liste(pos_possibles,taille_pos_possibles,jumped_case)==0))
                {
                    //j'ajoute jumped_case à pos_possibles
                    pos_possibles[taille_pos_possibles] = jumped_case;

                    printf("j'ai ajouté %u à pos_possibles\n",pos_possibles[taille_pos_possibles]);

                    taille_pos_possibles ++;

                    //je recupere les vecteurs pointants sur les voisins de jumped case.
                    struct neighbors_t voisins_de_jumped = get_neighbors(jumped_case);
                    int j = 0;

                    //je regarde si on peut poursuivre un saut multiple en parcourant les voisins de jumped_case 
                    while((existence_ennemi==0)&&(j<MAX_NEIGHBORS))
                    {
                        struct vector_t vect_case_voisin_jumped = voisins_de_jumped.n[j]; 
                        unsigned int case_voisin_jumped = vect_case_voisin_jumped.i;
                        unsigned int direction_voisin_jumped = vect_case_voisin_jumped.d;
                        
                        unsigned int next_jumped_case = get_neighbor(case_voisin_jumped,direction_voisin_jumped);

                        printf("next_jumped_case est %u", next_jumped_case);

                        if( (case_voisin_jumped!=UINT_MAX)&&
                            (dans_liste(s_joueur->positions,s_joueur->size,case_voisin_jumped)==0)&&
                            (dans_liste(s_ennemi->positions,s_ennemi->size,case_voisin_jumped)==1)&&
                            (next_jumped_case!=UINT_MAX)&&
                            (dans_liste(pos_possibles,taille_pos_possibles,next_jumped_case)==0)&&
                            (dans_liste(s_joueur->positions,s_joueur->size,next_jumped_case)==0)&&
                            (dans_liste(s_ennemi->positions,s_ennemi->size,next_jumped_case)==0))
                        {
                            existence_ennemi = 1; 
                            jumped_case = next_jumped_case;
                            printf("jumped_case devient next_jump_case");
                        }

                        j++;
                    }
                }
            }
        }
    }
    printf("il y a %d positions possibles à partir de %d", taille_pos_possibles, idx);
    unsigned int case_choisie = rand()%(taille_pos_possibles+1);
    return(pos_possibles[case_choisie]);
}
*/

int main(int argc, char *argv[])
{
    //printf("%s  rouge%s  bleu%s  vert\n", KRED, KBLU, KGRN);
    int a = 2<3; 
    printf("%d\n", a);
    return 0;
}