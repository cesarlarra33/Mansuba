#ifndef _INIT_GAME_H
#define _INIT_GAME_H

#include "positions.h"


void print_type_vict(unsigned int type_victoire);


void print_type_game_board(unsigned int seed);


/** fonction qui place les pièces dans la configuration de départ choisie (0 pour l'instant) dans le monde en fonction de la forme du monde */
void init_set_p0(unsigned int choix_pos_depart, struct set *s);

void init_set_p1(unsigned int choix_pos_depart, struct set *s);


/** Initialises the pieces' positions at the beginnig of the game. */
void world_depart(unsigned int choix_pos_depart, struct world_t *w, struct set *current_pos_p0, struct set *current_pos_p1);


#endif