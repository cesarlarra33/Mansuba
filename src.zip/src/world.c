#include <stdio.h>
#include <string.h>

#include "world.h"



struct world_t
{
    enum color_t color[WORLD_SIZE];
    enum sort_t sort[WORLD_SIZE];
};

struct world_t world;


/** Initializes a world (NO_COLOR, NO_SORT everywhere)
    Always returns the same pointer */
struct world_t* world_init()
{
  for(int i=0; i<WORLD_SIZE; i++)
  {
    world.color[i]=NO_COLOR;
    world.sort[i]=NO_SORT;
  }
  return &world;
}


/** Return the color at a place */
enum color_t world_get(const struct world_t* b, unsigned int idx)
{
    return b->color[idx];
}


/** Sets the color at a place */
void world_set(struct world_t* b, unsigned int idx, enum color_t c)
{
    b->color[idx] = c;
}


/** Return the sort at a place */
enum sort_t world_get_sort(const struct world_t* b, unsigned int idx)
{
    return b->sort[idx];
}


/** Sets the sort at a place */
void world_set_sort(struct world_t* b, unsigned int idx, enum sort_t c)
{
    b->sort[idx] = c;
}